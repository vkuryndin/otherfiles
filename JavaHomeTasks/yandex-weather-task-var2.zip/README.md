Yandex weather task about parsing json
