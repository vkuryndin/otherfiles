package org.example;

import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main {

    //creating OkHttpClient and ObjectMapper instances, which are used for making HTTP requests and parsing JSON responses
    private static final OkHttpClient HTTP = new OkHttpClient();
    private static final ObjectMapper JSON = new ObjectMapper();

    public static void main(String[] args) throws IOException {

        System.out.println("Hello and welcome! This is my Weather task");
        System.out.println("");
        System.out.println("args.length = " + args.length + ", args = " + java.util.Arrays.toString(args));
        System.out.println("query before geocode = " + ((args.length > 0) ? String.join(" ", args) : "Москва, Россия"));

        //reading keys from environment
        String apiKey = System.getenv("YANDEX_WEATHER_KEY");
        String geocoderKey = System.getenv("YANDEX_GEOCODER_KEY");
        if (apiKey == null || apiKey.isBlank()) {
            System.err.println("No YANDEX_WEATHER_KEY environment variable found");
            System.exit(1);
        }
        if (geocoderKey == null || geocoderKey.isBlank()) {
            System.err.println("No YANDEX_GEOCODER_KEY environment variable found");
            System.exit(1);
        }

        String query = (args.length > 0) ? String.join(" ", args) : "Москва, Россия";

        //choosing latitude and longitude for the request (Moscow)
        //double lat = 55.752222;
        //double lon = 37.615556;
        int days = 5;

        YandexGeocoder geocoder = new YandexGeocoder(HTTP, JSON, geocoderKey);
        LatLon latLon = geocoder.geocode(query);
        System.out.printf("→ '%s' → lat=%.6f, lon=%.6f%n", query, latLon.lat(), latLon.lon());

        //creating url for my request
        HttpUrl url = new HttpUrl.Builder()
                .scheme("https")
                .host("api.weather.yandex.ru")
                .addPathSegment("v2")
                .addPathSegment("forecast")
                .addQueryParameter("lat", String.valueOf(latLon.lat()))
                .addQueryParameter("lon", String.valueOf(latLon.lon()))
                .addQueryParameter("limit", String.valueOf(days))
                .build();

        //HttpUrl url = HttpUrl.parse("https://api.weather.yandex.ru/v2/forecast")
        //        .newBuilder()
        //        .addQueryParameter("lat", String.valueOf(lat))
        //        .addQueryParameter("lon", String.valueOf(lon))
        //        .addQueryParameter("limit", String.valueOf(days))
        //        .build();

        //creating a request with my yandex weather key and executing it
        Request request = new Request.Builder()
                .url(url)
                .addHeader("X-Yandex-API-Key", apiKey)
                .build();

        try (Response response = HTTP.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                String err = response.body() != null ? response.body().string() : "";
                System.err.println("Request failed with code: " + response.code());
                System.exit(2);
            }
            ResponseBody responseBody = response.body();
            if (responseBody == null) {
                System.err.println("Response body is null");
                System.exit(3);
            }

            //displaying unformatted full json text
            String jsonText = responseBody.string();
            System.out.println("===Full JSON text===");
            System.out.println(jsonText);

            //displaying formatted full json text
            JsonNode root = JSON.readTree(jsonText);
            String pretty = JSON.writerWithDefaultPrettyPrinter().writeValueAsString(root);
            System.out.println("===Full JSON text PRETTY format===");
            System.out.println(pretty);

            //writing to file
            SaveFile saveFile = new SaveFile(pretty, "yandex_forecast_", "Weather data written to file: ");
            saveFile.saveToFile();


            //displaying current temperature
            JsonNode tempNode = root.path("fact").path("temp");
            if (tempNode.isNumber()) {
                System.out.println("Current temperature: (fact.temp): " + tempNode.asInt() + "°C");
            } else {
                System.out.println("Current temperature: (fact.temp): no data ");
            }

            //displaying average temperature for the next 5 days, using 5 days limit
            List<Integer> dayAverages = new ArrayList<>();
            JsonNode forecasts = root.path("forecasts");
            if (forecasts.isArray()) {
                for (JsonNode day : forecasts) {
                    JsonNode avg = day.path("parts").path("day").path("temp_avg");
                    if (avg.isNumber()) {
                        dayAverages.add(avg.asInt());
                    }
                }
            }
            if (dayAverages.isEmpty()) {
                System.out.println("No day averages found");
            } else {
                double sum = 0;
                for (int t : dayAverages) sum += t;
                double avg = sum / dayAverages.size();
                System.out.println("Average temperature for the next 5 days: " + avg + "°C");
            }


        } catch (IOException e) {
            System.err.println("Request failed with exception: " + e.getMessage());
            e.printStackTrace();
            System.exit(4);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
//        for (int i = 1; i <= 5; i++) {
    //TIP Press <shortcut actionId="Debug"/> to start debugging your code. We have set one <icon src="AllIcons.Debugger.Db_set_breakpoint"/> breakpoint
    // for you, but you can always add more by pressing <shortcut actionId="ToggleLineBreakpoint"/>.
    //           System.out.println("i = " + i);
    //       }




}
