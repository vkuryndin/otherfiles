package org.example;

//class for storing latitude and longitude in decimal degrees
public final class LatLon {
    private final double lat;
    private final double lon;

    //constructor
    public LatLon(double lat, double lon) {
        this.lat = lat;
        this.lon = lon;
    }

    //accessor methods
    public double lat() { return lat; }
    public double lon() { return lon; }

    // returning human-readable string representation of the object
    @Override
    public String toString() {
        return "LatLon{lat=" + lat + ", lon =" + lon + '}';
    }
}
