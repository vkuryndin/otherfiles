package org.example;

import java.nio.charset.StandardCharsets;
import java.nio.file.FileStore;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

//the special class allowing us to safe the pretty json string to the file

public final class SaveFile {
    private final String pretty;
    private final String fileName;
    private final String consoleMessage;

    //constructor
    public SaveFile(String pretty, String fileName, String consoleMessage) throws Exception {

        //checking whether all arguments are not OK
        if (pretty == null || fileName == null || consoleMessage == null) {
            throw new IllegalArgumentException("SaveFile: pretty, fileName or consoleMessage is null");
        }
        this.pretty = pretty;
        this.fileName = fileName;
        this.consoleMessage = consoleMessage;
    }

    public void saveToFile() throws Exception {
        Path outDir = Path.of("build", "weather");

        // checkin if a directory exists, if not create it, if error occurs throw exception
        if (!Files.notExists(outDir)) {
            Files.createDirectories(outDir);
        } else if (!Files.isDirectory(outDir)) {
            throw new IllegalStateException("Path exists but is not a directory: " + outDir.toAbsolutePath());
        }

        //check if we can write to this directory
        if (!Files.isWritable(outDir)) {
            throw new IllegalStateException("Directory is not writable: " + outDir.toAbsolutePath());
        }

        //checking for available space on the disk
        byte[] bytes = pretty.getBytes(StandardCharsets.UTF_8);
        try {
            FileStore store = Files.getFileStore(outDir);
            long free = store.getUsableSpace();
            System.out.println("Available space on the disk: " + free + " bytes");
            System.out.println("Available space on the disk: " + free/(1024*1024) + " Mbytes");
            if (free < bytes.length) {
                throw new IllegalStateException("Not enough space on the disk: need " + bytes.length + "bytes, free" + free);
            }
        } catch (Exception ignore) {
            //skipping exception
        }

        // creating string pattern
        String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        Path out = outDir.resolve(fileName + ts + ".json");  //yandex_forecast_

        //creating a file and writing pretty json string to it
        Files.writeString(out, pretty, StandardCharsets.UTF_8);
        System.out.println();
        System.out.println("===" + consoleMessage + out.toAbsolutePath() + "==="); // "===Weather data written to file: "
        System.out.println();
    }
}
