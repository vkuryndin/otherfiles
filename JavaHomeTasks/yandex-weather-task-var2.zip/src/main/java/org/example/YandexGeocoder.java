package org.example;

import com.fasterxml.jackson.databind.JsonNode;
import okhttp3.*;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;

public final class YandexGeocoder {
    private final OkHttpClient http;
    private final ObjectMapper json;
    private final String apiKey;

    //constructor
    public YandexGeocoder(OkHttpClient http, ObjectMapper json, String apiKey) {
        this.http = http;
        this.json = json;
        this.apiKey = apiKey;
    }

    //method to get latitude and longitude for the given query
    //returns LatLon instance with latitude and longitude
    //throws IOException if geocoder returns an error or if response body is empty

    //first we conmstruct a orrect query using my Yandex GeoCode API key
    public LatLon geocode(String query) throws IOException {
        HttpUrl url = new HttpUrl.Builder()
                .scheme("https")
                .host("geocode-maps.yandex.ru")
                .addPathSegment("v1")
                .addQueryParameter("apikey", apiKey)
                .addQueryParameter("geocode", query)
                .addQueryParameter("lang", "ru_RU")
                .addQueryParameter("format", "json")
                .addQueryParameter("results", "1")
                .build();
        System.out.println("Geocoder URL (encoded): " + url);

        // than we create a request and execute it
        Request req = new Request.Builder().url(url).build();

        try (Response response = http.newCall(req).execute()) {
            if (!response.isSuccessful()) {
                String err = response.body() != null ? response.body().string() : "";
                throw new IOException("Geocoder http failed with code: " + response.code());
            }
            if (response.body() == null) { throw new IOException("Empty response body"); }
            String responseBody = response.body().string();

            //here we are parsing json response to the Jackson tr0ee
            JsonNode jsonNode = json.readTree(responseBody);

            //preparing the string to save into the file and launching SaveFile class to execute saving to file
            String pretty = json.writerWithDefaultPrettyPrinter().writeValueAsString(jsonNode);
            SaveFile saveFile = new SaveFile(pretty, "yandex_geocoder_", "Geocoder response saved to file: ");
            saveFile.saveToFile();

            //finding an array of featureMember objects according to documentation this is an array of results acquired from Geocoder
            JsonNode fm = jsonNode.path("response")
                    .path("GeoObjectCollection")
                    .path("featureMember");

            //checking whether response is valid
            if (!fm.isArray() || fm.size() == 0) {
                throw new IOException("Geocoder returned empty featureMember for query: " + query +
                        ". Body: " + responseBody);
            }

            //getting coordinates from the first featureMember object

            JsonNode first = fm.get(0);
            if (first == null || first.isMissingNode() || !first.isObject()) {
                throw new IOException("Geocoder: featureMember[0] missing. Body: " + responseBody);
            }

            JsonNode posNode = first.path("GeoObject").path("Point").path("pos");
            if (!posNode.isTextual() || posNode.asText().isBlank()) {
                throw new IOException("Geocoder: 'pos' not found at featureMember[0].GeoObject.Point.pos. " +
                        "Body: " + responseBody);
            }

            //converting the string with coordinates to numerics (doubles)
            String pos = posNode.asText().trim();
            String[] parts = pos.split("\\s+");
            if (parts.length < 2) {
                throw new IOException("Geocoder returned invalid coordinates: " + pos);
            }

            double lon = Double.parseDouble(parts[0]);
            double lat = Double.parseDouble(parts[1]);

            //checking the correct order of the coordinates and swapping them if needed
            if (Math.abs(lat) > 90 || Math.abs(lon) > 180) {
                double tmp = lat;
                lat = lon;
                lon = tmp;
            }
            return new LatLon(lat, lon);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
