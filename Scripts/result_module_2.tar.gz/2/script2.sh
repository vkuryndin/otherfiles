#!/bin/bash
# it is recommended to run the sript with sudo to check all the logs
# enabling stop on any error, also prohibit non initialized variables
set -euo pipefail
#set -x   #using for debugging
#i decided to search  withourt paying to attention 
#to caps/or no caps, because there were no ERRORS in my directory

keyword="error" 

#checking whether the  user specified the directory
if [ $# -lt 1 ]; then
 echo "Error: yous should sepcify a directory"
 echo "Usage: $0 /path/to/a/directory with log files"
 exit 1
fi

directory="$1"

if [ ! -d "$directory" ]; then
  echo "Error: $directory is not a directory"
  exit 1
fi

#creating a variable for total found string
total=0

#searching  for fils in the provided directory
for file in "$directory"/*.log; do
 [ -e "$file" ] || continue
 count=$(grep -i -c -- "$keyword" "$file" || true)

 if (( count > 0 )); then 
  echo "File $(basename "$file") contains $count of rows with keyword $keyword"
  total=$(( total + count ))
 fi
done

echo "Total number of rows with the keyword $keyword in all log files: $total" 

